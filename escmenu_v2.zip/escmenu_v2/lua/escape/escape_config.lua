
ESC.cfg.Community = ""

ESC.cfg.DefaultTheme = "clear"

ESC.cfg.Background = false


ESC.cfg.CenterButtons = true


ESC.cfg.Snow = true

ESC.cfg.Themes[ "dark" ] = {
    Base = Color( 35, 35, 35 ),
    PlayerBox = Color( 45, 45, 45 ),
    Text = Color( 230, 230, 230 ),
    TextSecondary = Color( 120, 120, 120 ),
    Accent = Color( 0, 178, 238 ),
    TabColor = Color( 0, 0, 0, 0 ),
    Background = Color( 0, 0, 0, 0 ),
    Blur = true,
    BlackAndWhite = true,
    FadeTime = .5
}

ESC.cfg.Themes[ "clear" ] = {
    Base = Color( 35, 35, 35, 160 ),
    PlayerBox = Color( 45, 45, 45, 150 ),
    Text = Color( 230, 230, 230 ),
    TextSecondary = Color( 232, 76, 82, 100 ),
    Accent = Color( 232, 76, 82, 100 ),
    TabColor = Color( 0, 0, 0, 0 ),
    Background = Color( 0, 0, 0, 00 ),
    Blur = true,
    BlackAndWhite = false,
    FadeTime = .5
}

-- Leak by Rubi